Superstars Web Browser v1.0
By Crystal Tatsuya

How to do it:
-Download a .zip file at the page: http://superjumppunch.webs.com/games-and-other-stuff
-Extract the Superstars Web Browser v1.0 from the .zip file.
-Enjoy!

Usage:
-Allow you to surf the website. Functions the same way as Internet Explorer.

Updates in the next update:
-Menustrips
-Welcome message
-Logo with a link on it.

If I needed updates, you can help me because the Superstars Web Browser was made with Microsoft Visual Basic 2010 Express.

Thanks!